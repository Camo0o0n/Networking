﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiplayer_Games_Programming_Framework.Core
{
	internal enum GameModeState
	{
		AWAKE,
		STARTING,
		PLAYING,
		ENDING
	}
}
