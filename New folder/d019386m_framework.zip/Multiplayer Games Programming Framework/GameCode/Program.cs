﻿using var game = new Multiplayer_Games_Programming_Framework.MainGame();
game.Run();


