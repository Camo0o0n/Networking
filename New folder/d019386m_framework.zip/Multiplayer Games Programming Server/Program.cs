﻿using Multiplayer_Games_Programming_Server;

Server server = new Server("127.0.0.1", 4444);
server.Start();
